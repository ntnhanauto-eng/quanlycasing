</main> <!-- Đóng thẻ main đã mở từ header.php -->

    <style>
        .footer {
            background-color: #f8f9fa; /* Màu nền xám cực nhẹ */
            color: #555;              /* Màu chữ xám đậm cho dịu mắt */
            text-align: center;       /* CĂN GIỮA CHỮ */
            padding: 20px 10px;       /* Tạo khoảng cách trên dưới */
            font-size: 13px;
            border-top: 1px solid #e0e0e0; /* Đường kẻ mỏng ngăn cách với nội dung */
            margin-top: 30px;
        }

       
    </style>

    <div class="footer">
        © 04-2026 Developed by Nguyen Thanh Nhan - E/R Outfitting 1
    </div>
    
</body>
</html>